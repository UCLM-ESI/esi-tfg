Este directorio contiene un ejemplo «mínimo» de memoria de Trabajo Fin
de Grado según las normas de la Escuela Superior de Informática de
Ciudad Real. Puede que no cumpla alguna de dichas normas, pero lo
iremos perfeccionando.

http://webpub.esi.uclm.es/archivos/216/NormativaTFG

EDICIÓN
=======
Se recomienda enérgicamente utilizar un sistema operativo GNU/Linux (como
Debian) y el editor GNU Emacs (versión 23 o mayor) y el modo "auctex".


DEPENDENCIAS
============
- arco-authors (https://uclm-arco.github.io/debian/)

Paquetes Debian oficiales
-------------------------
- texlive-latex-extra
- lmodern
- texlive-lang-spanish
- texlive-latex-recommended
- cm-super
- rubber
- inkscape
- dia
- auctex
