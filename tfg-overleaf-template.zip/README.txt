Este directorio contiene un ejemplo «mínimo» de memoria de Trabajo Fin de Grado
según las normas de la Escuela Superior de Informática de Ciudad Real. Puede que
no cumpla alguna de dichas normas, pero lo iremos perfeccionando.

https://pruebasaluuclm.sharepoint.com/sites/esicr/tfg/SitePages/Inicio.aspx

Empieza editando el fichero "metadata.tex" para poner tu nombre, el título de tu
proyecto y otra información específica.
