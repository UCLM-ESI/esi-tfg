// -*- coding:utf-8 -*-

// Sí, desde hace años que también funciona con acentos!
// Este código está en un fichero C externo con coding UTF-8.
#include <stdio.h>
int main(int argc, char* argv[]) {
  puts("Hola mundo!");
}

// más
